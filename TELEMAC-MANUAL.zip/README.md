# TELEMAC-MANUAL
 An intuitive and beginner friendly openTelemac-Mascaret user/ training manual
